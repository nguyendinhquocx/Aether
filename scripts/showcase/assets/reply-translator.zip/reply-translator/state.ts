export type State = { status: "idle" | "loading" | "ready" | "error"; text?: string };
export const translations = new Map<string, State>();
export const key = (session: string, message: string, revision: string, language: string) => JSON.stringify([session, message, revision, language]);
